"use strict";exports.id=5615,exports.ids=[2814,5615],exports.modules={13808:(a,b,c)=>{c.d(b,{$N:()=>f,OK:()=>g,Zl:()=>h,lz:()=>i});var d=c(55511),e=c.n(d);function f(a=32){return e().randomBytes(a).toString("base64url")}function g(a){return e().createHash("sha256").update(a).digest("base64url")}function h(){return e().randomBytes(32).toString("base64url")}function i(a=32){let b=f(a),c=g(b);return{codeVerifier:b,codeChallenge:c,state:h()}}},22898:(a,b,c)=>{c.d(b,{Hd:()=>n,IF:()=>s,Pd:()=>h,Y0:()=>r,ZP:()=>x,_V:()=>w,cn:()=>o,dR:()=>p,i7:()=>i,jl:()=>z,nu:()=>A,uw:()=>y});var d=c(81630),e=c.n(d),f=c(1932),g=c(92990);function h(a,b=null){return new Promise((c,d)=>{let g=e().createServer((b,c)=>{let d=new f.URL(b.url,"http://localhost");if("/callback"===d.pathname||"/auth/callback"===d.pathname){let b=Object.fromEntries(d.searchParams);c.writeHead(200,{"Content-Type":"text/html; charset=utf-8"}),c.end(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Authentication Successful</title>
  <style>
    body { font-family: system-ui; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #f5f5f5; }
    .container { text-align: center; padding: 2rem; background: white; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    .success { color: #22c55e; font-size: 3rem; }
    h1 { margin: 1rem 0; }
    p { color: #666; }
    #countdown { font-weight: bold; }
  </style>
</head>
<body>
  <div class="container">
    <div class="success">&#10003;</div>
    <h1>Authentication Successful</h1>
    <p id="message">Closing in <span id="countdown">3</span> seconds...</p>
  </div>
  <script>
    let count = 3;
    const countdown = document.getElementById("countdown");
    const message = document.getElementById("message");
    const timer = setInterval(() => {
      count--;
      countdown.textContent = count;
      if (count <= 0) {
        clearInterval(timer);
        window.close();
        setTimeout(() => {
          message.textContent = "Please close this tab manually.";
        }, 500);
      }
    }, 1000);
  </script>
</body>
</html>`),a(b)}else c.writeHead(404),c.end("Not found")});g.listen(b||0,"127.0.0.1",()=>{let{port:a}=g.address();c({server:g,port:a,close:()=>g.close()})}),g.on("error",a=>{"EADDRINUSE"===a.code&&b?d(Error(`Port ${b} is already in use. Please close other applications using this port.`)):d(a)})})}function i(a,b=g.Ww,c=100){return new Promise((d,e)=>{let f=null,g=null,h=()=>{f&&(clearInterval(f),f=null),g&&(clearTimeout(g),g=null)};g=setTimeout(()=>{h(),e(Error("Authentication timeout (5 minutes)"))},b),f=setInterval(()=>{let b=a();b&&(h(),d(b))},c)})}let j=null,k=null,l=g.DI.fixedPort,m=new Map;function n({state:a,codeVerifier:b,redirectUri:c}){return!!a&&!!b&&!!c&&(m.set(a,{codeVerifier:b,redirectUri:c,status:"pending",createdAt:Date.now()}),!0)}function o(a){return m.get(a)||null}function p(a){m.delete(a)}function q(a,b){let c=a?"Authentication Successful":"Authentication Failed",d=String(b).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");return`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>${c}</title>
<style>body{font-family:system-ui;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;background:#f5f5f5}.c{text-align:center;padding:2rem;background:#fff;border-radius:8px;box-shadow:0 2px 10px rgba(0,0,0,.1)}.i{color:${a?"#22c55e":"#ef4444"};font-size:3rem}h1{margin:1rem 0}p{color:#666}</style>
</head><body><div class="c"><div class="i">${a?"&#10003;":"&#10007;"}</div><h1>${c}</h1><p>${d}</p><p>Closing in <span id="cd">3</span>s...</p>
<script>let n=3;const c=document.getElementById("cd");const t=setInterval(()=>{n--;c.textContent=n;if(n<=0){clearInterval(t);window.close();}},1000);</script>
</div></body></html>`}function r(a){return new Promise(b=>{if(j)return void b({success:!0});let d=e().createServer(async(b,d)=>{let e=new f.URL(b.url,"http://localhost");if("/callback"!==e.pathname&&"/auth/callback"!==e.pathname){d.writeHead(404),d.end("Not found");return}let g=e.searchParams.get("code"),h=e.searchParams.get("state"),i=e.searchParams.get("error"),j=h?m.get(h):null;if(j){try{if(i)throw Error(e.searchParams.get("error_description")||i);if(!g)throw Error("No authorization code received");let{exchangeTokens:a}=await Promise.all([c.e(7774),c.e(4646),c.e(3904),c.e(8851),c.e(7353),c.e(9276),c.e(2547),c.e(9356),c.e(369),c.e(6606)]).then(c.bind(c,17085)),{createProviderConnection:b}=await c.e(1998).then(c.bind(c,71998)),f=await a("codex",g,j.redirectUri,j.codeVerifier,h),k=await b({provider:"codex",authType:"oauth",...f,expiresAt:f.expiresIn?new Date(Date.now()+1e3*f.expiresIn).toISOString():null,testStatus:"active"});j.status="done",j.connectionId=k.id,j.email=k.email,d.writeHead(200,{"Content-Type":"text/html; charset=utf-8"}),d.end(q(!0,"You can close this window."))}catch(a){j.status="error",j.error=a.message,d.writeHead(200,{"Content-Type":"text/html; charset=utf-8"}),d.end(q(!1,a.message))}finally{s()}return}let k=`http://localhost:${a}/callback${e.search}`;d.writeHead(302,{Location:k}),d.end(),s()});d.listen(l,"127.0.0.1",()=>{j=d,k=setTimeout(()=>s(),3e5),b({success:!0})}),d.on("error",a=>{"EADDRINUSE"===a.code?b({success:!1,reason:"port_busy"}):b({success:!1,reason:a.message})})})}function s(){k&&(clearTimeout(k),k=null),j&&(j.close(),j=null)}let t=null,u=null,v=new Map;function w({state:a,codeVerifier:b,redirectUri:c}){return!!a&&!!b&&!!c&&(v.set(a,{codeVerifier:b,redirectUri:c,status:"pending",createdAt:Date.now()}),!0)}function x(a){return v.get(a)||null}function y(a){v.delete(a)}function z(a){return new Promise(b=>{if(t)return void b({success:!0});let d=e().createServer(async(b,d)=>{let e=new f.URL(b.url,"http://localhost");if("/callback"!==e.pathname&&"/auth/callback"!==e.pathname){d.writeHead(404),d.end("Not found");return}let g=e.searchParams.get("code"),h=e.searchParams.get("state"),i=e.searchParams.get("error"),j=h?v.get(h):null;if(j){try{if(i)throw Error(e.searchParams.get("error_description")||i);if(!g)throw Error("No authorization code received");let{exchangeTokens:a}=await Promise.all([c.e(7774),c.e(4646),c.e(3904),c.e(8851),c.e(7353),c.e(9276),c.e(2547),c.e(9356),c.e(369),c.e(6606)]).then(c.bind(c,17085)),{createProviderConnection:b}=await c.e(1998).then(c.bind(c,71998)),f=await a("xai",g,j.redirectUri,j.codeVerifier,h),k=await b({provider:"xai",authType:"oauth",...f,expiresAt:f.expiresIn?new Date(Date.now()+1e3*f.expiresIn).toISOString():null,testStatus:"active"});j.status="done",j.connectionId=k.id,j.email=k.email,d.writeHead(200,{"Content-Type":"text/html; charset=utf-8"}),d.end(q(!0,"You can close this window."))}catch(a){j.status="error",j.error=a.message,d.writeHead(200,{"Content-Type":"text/html; charset=utf-8"}),d.end(q(!1,a.message))}finally{A()}return}let k=`http://localhost:${a}/callback${e.search}`;d.writeHead(302,{Location:k}),d.end(),A()});d.listen(56121,"127.0.0.1",()=>{t=d,u=setTimeout(()=>A(),3e5),b({success:!0})}),d.on("error",a=>{"EADDRINUSE"===a.code?b({success:!1,reason:"port_busy"}):b({success:!1,reason:a.message})})})}function A(){u&&(clearTimeout(u),u=null),t&&(t.close(),t=null)}},95540:(a,b,c)=>{c.d(b,{Ue:()=>k,oT:()=>l});var d=c(39141);let e=d.xq.xai?.clientId,f="https://auth.x.ai",g="/oauth2/authorize",h="/oauth2/token",i="/.well-known/openid-configuration",j="/callback",k=96,l={clientId:e,issuer:f,authEndpointPath:g,tokenEndpointPath:h,discoveryPath:i,authorizeUrl:`${f}${g}`,tokenUrl:`${f}${h}`,discoveryUrl:`${f}${i}`,scope:"openid profile email offline_access grok-cli:access api:access",apiBaseUrl:"https://api.x.ai/v1",redirectUri:`http://127.0.0.1:56121${j}`,loopbackPort:56121,callbackPath:j,pkceVerifierBytes:96,refreshLeadSeconds:300,userAgent:"grok-cli/9router",codeChallengeMethod:"S256"}}};