// Quota auto-ping scheduler: sends tiny opt-in requests around resets or to start inactive windows.
import "open-sse/index.js";

import { getSettings, getProviderConnections, updateProviderConnection } from "@/lib/localDb";
import { getClaudeUsage } from "open-sse/services/usage/claude.js";
import { getCodexUsage, getCodexModels } from "open-sse/services/usage/codex.js";
import { getExecutor } from "open-sse/executors/index.js";
import { CLAUDE_CLI_SPOOF_HEADERS } from "open-sse/providers/shared.js";
import { proxyAwareFetch } from "open-sse/utils/proxyFetch.js";
import { resolveConnectionProxyConfig } from "@/lib/network/connectionProxy";
import { refreshAndUpdateCredentials } from "@/app/api/usage/[connectionId]/route.js";
import { QUOTA_AUTOPING_CONFIG } from "@/shared/constants/config";

const C = QUOTA_AUTOPING_CONFIG;
const CLAUDE_PING_URL = "https://api.anthropic.com/v1/messages?beta=true";

const providerHandlers = {
  claude: {
    getUsage: (accessToken, _providerSpecificData, proxyOptions) => getClaudeUsage(accessToken, proxyOptions),
    sendPing: sendClaudePing,
  },
  codex: {
    getUsage: getCodexUsage,
    getModels: getCodexModels,
    sendPing: sendCodexPing,
  },
};

// Survive Next.js hot reload and keep one scheduler per server process.
const g = (global.__quotaAutoPing ??= {
  interval: null,
  running: false,
  resetCache: {},
  failureCache: {},
  pingCache: {},
});

function cacheKey(provider, connectionId) {
  return `${provider}:${connectionId}`;
}

function normalizeResetKey(resetAt) {
  const ms = new Date(resetAt).getTime();
  if (!Number.isFinite(ms)) return resetAt;
  return new Date(Math.floor(ms / 60000) * 60000).toISOString();
}

function getResetDriftMs(previousResetAt, nextResetAt) {
  const previousMs = new Date(previousResetAt).getTime();
  const nextMs = new Date(nextResetAt).getTime();
  if (!Number.isFinite(previousMs) || !Number.isFinite(nextMs)) return 0;
  return nextMs - previousMs;
}

function toFiniteNumber(value, fallback = null) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const parsed = Number(value);
    if (Number.isFinite(parsed)) return parsed;
  }
  return fallback;
}

function isQuotaExhausted(quota) {
  if (!quota || quota.unlimited === true) return false;
  const remaining = toFiniteNumber(quota.remaining);
  if (remaining !== null) return remaining <= 0;

  const used = toFiniteNumber(quota.used);
  const total = toFiniteNumber(quota.total);
  return total !== null && total > 0 && used !== null && used >= total;
}

function wasPingedRecently(connection, intervalMs, nowMs = Date.now(), inMemoryPingAt = null) {
  if (!intervalMs) return false;
  const persistedPingAt = new Date(connection.lastPingAt).getTime();
  const memoryPingAt = toFiniteNumber(inMemoryPingAt, Number.NEGATIVE_INFINITY);
  const lastPingAtMs = Math.max(
    Number.isFinite(persistedPingAt) ? persistedPingAt : Number.NEGATIVE_INFINITY,
    memoryPingAt,
  );
  return Number.isFinite(lastPingAtMs) && nowMs - lastPingAtMs < intervalMs;
}

function isBlockingQuotaName(name, sessionKey) {
  if (name === sessionKey) return false;
  return !String(name).toLowerCase().includes("session");
}

function hasExhaustedBlockingQuota(quotas, sessionKey) {
  return Object.entries(quotas || {}).some(([name, quota]) => isBlockingQuotaName(name, sessionKey) && isQuotaExhausted(quota));
}

function hasAvailableWeeklyQuota(quotas) {
  const weekly = Object.entries(quotas || {})
    .filter(([name]) => String(name).toLowerCase().startsWith("weekly"));
  return weekly.length > 0 && weekly.every(([, weeklyQuota]) => !isQuotaExhausted(weeklyQuota));
}

function isSelectedProxyAvailable(connection, proxyConfig) {
  const selectedPoolId = String(connection.providerSpecificData?.proxyPoolId ?? "").trim();
  if (!selectedPoolId || selectedPoolId === "__none__") return true;
  return proxyConfig?.proxyUnavailable !== true
    && proxyConfig?.source !== "unavailable"
    && String(proxyConfig?.proxyPoolId ?? "").trim() === selectedPoolId
    && Boolean(proxyConfig?.proxyPool);
}

function shouldPingInactiveSession(connection, providerConfig, quotas, quota, proxyConfig, now, inMemoryPingAt) {
  return providerConfig.pingInactiveSession === true
    && quota
    && !quota.resetAt
    && !isQuotaExhausted(quota)
    && hasAvailableWeeklyQuota(quotas)
    && !hasExhaustedBlockingQuota(quotas, providerConfig.quotaKey)
    && isSelectedProxyAvailable(connection, proxyConfig)
    && !wasPingedRecently(connection, providerConfig.inactiveMinPingIntervalMs, now, inMemoryPingAt);
}

function shouldPingForReset(providerConfig, cachedReset, resetAt, now) {
  if (providerConfig.pingWhenResetAtSlides) {
    return Boolean(cachedReset) && getResetDriftMs(cachedReset, resetAt) >= (providerConfig.resetAtDriftMs || 0);
  }

  const resetMs = new Date(resetAt).getTime();
  return Number.isFinite(resetMs) && now >= resetMs - C.pingLeadMs;
}

function buildProxyOptions(cfg) {
  return {
    connectionProxyEnabled: cfg.connectionProxyEnabled === true,
    connectionProxyUrl: cfg.connectionProxyUrl || "",
    connectionNoProxy: cfg.connectionNoProxy || "",
    vercelRelayUrl: cfg.vercelRelayUrl || "",
    strictProxy: false,
  };
}

async function sendClaudePing(connection, providerConfig, proxyOptions, deps) {
  const res = await deps.proxyAwareFetch(CLAUDE_PING_URL, {
    method: "POST",
    headers: {
      ...CLAUDE_CLI_SPOOF_HEADERS,
      "Authorization": `Bearer ${connection.accessToken}`,
      "content-type": "application/json",
    },
    body: JSON.stringify({
      model: providerConfig.pingModel,
      max_tokens: providerConfig.pingMaxTokens,
      messages: [{ role: "user", content: providerConfig.pingText }],
    }),
  }, proxyOptions);
  if (!res.ok) {
    try { await res.body?.cancel?.(); } catch { /* noop */ }
    return false;
  }
  await drainResponseBody(res);
  return true;
}

function buildCodexPingInput(text) {
  return [{
    type: "message",
    role: "user",
    content: [{ type: "input_text", text }],
  }];
}

async function drainResponseBody(response) {
  if (typeof response?.text === "function") {
    await response.text();
    return;
  }

  const reader = response?.body?.getReader?.();
  if (!reader) return;

  try {
    while (true) {
      const { done } = await reader.read();
      if (done) return;
    }
  } finally {
    reader.releaseLock?.();
  }
}

async function sendCodexPing(connection, providerConfig, model, proxyOptions, deps) {
  const executor = deps.getExecutor("codex");
  const { response } = await executor.execute({
    model,
    stream: true,
    credentials: {
      accessToken: connection.accessToken,
      connectionId: connection.id,
      idToken: connection.idToken,
      providerSpecificData: connection.providerSpecificData,
    },
    proxyOptions,
    log: console,
    body: {
      model,
      input: buildCodexPingInput(providerConfig.pingText),
      instructions: providerConfig.pingInstructions,
      reasoning: providerConfig.pingReasoningEffort
        ? { effort: providerConfig.pingReasoningEffort, summary: "auto" }
        : undefined,
      store: false,
      stream: true,
    },
  });
  if (!response.ok) {
    try { await response.body?.cancel?.(); } catch { /* noop */ }
    return false;
  }

  // Codex only starts the 5h window after the streaming response completes.
  await drainResponseBody(response);
  return true;
}

function shouldSkipAfterFailure(state, key, nowMs = Date.now()) {
  const failedAt = state.failureCache[key];
  return failedAt && nowMs - failedAt < C.failureCooldownMs;
}

async function pingConnection(conn, provider, providerConfig, handler, deps, state = g) {
  const key = cacheKey(provider, conn.id);

  // resetAt is stable for time-based windows; Codex polls every tick because inactive windows slide forward.
  const cachedReset = state.resetCache[key];
  if (!providerConfig.pingWhenResetAtSlides && cachedReset && Date.now() < new Date(cachedReset).getTime() - C.refreshAheadMs) return;

  // Avoid hammering provider auth/quota endpoints if a ping failed recently.
  if (shouldSkipAfterFailure(state, key)) return;

  const proxyCfg = await deps.resolveConnectionProxyConfig(conn.providerSpecificData);
  const proxyOptions = buildProxyOptions(proxyCfg);

  let connection = conn;
  try {
    const r = await deps.refreshAndUpdateCredentials(connection, false, proxyOptions);
    connection = r.connection;
  } catch (e) {
    state.failureCache[key] = Date.now();
    console.warn(`[AutoPing] ${provider}:${conn.id}: refresh failed: ${e.message}`);
    return;
  }

  const usage = await handler.getUsage(connection.accessToken, connection.providerSpecificData, proxyOptions, connection.idToken);
  const quotas = usage?.quotas || {};
  const quota = quotas?.[providerConfig.quotaKey];
  const resetAt = quota?.resetAt;
  const now = Date.now();
  const inactiveSession = shouldPingInactiveSession(
    connection,
    providerConfig,
    quotas,
    quota,
    proxyCfg,
    now,
    state.pingCache?.[key],
  );
  let resetKey = null;
  if (resetAt) {
    state.resetCache[key] = resetAt;

    if (providerConfig.skipWhenBlockingQuotaExhausted && hasExhaustedBlockingQuota(quotas, providerConfig.quotaKey)) return;
    if (isQuotaExhausted(quota)) return;

    resetKey = normalizeResetKey(resetAt);
    const lastPingedResetKey = connection.lastPingedResetKey || normalizeResetKey(connection.lastPingedResetAt);

    // Claude waits for reset. Codex pings only when resetAt slides, which means the 5h window is inactive.
    if (!shouldPingForReset(providerConfig, cachedReset, resetAt, now)) return;
    if (wasPingedRecently(connection, providerConfig.minPingIntervalMs, now)) return;
    if (lastPingedResetKey === resetKey) return;
  } else if (!inactiveSession) {
    return;
  }

  const model = provider === "codex"
    ? (await handler.getModels(connection.accessToken, proxyOptions, connection.providerSpecificData))[0]?.slug
    : providerConfig.pingModel;
  if (!model) {
    state.failureCache[key] = Date.now();
    console.warn(`[AutoPing] ${provider}:${connection.id}: no supported model available`);
    return;
  }

  const ok = provider === "codex"
    ? await handler.sendPing(connection, providerConfig, model, proxyOptions, deps)
    : await handler.sendPing(connection, providerConfig, proxyOptions, deps);
  if (!ok) {
    // Do not mark reset as pinged unless upstream accepted the tiny request.
    state.failureCache[key] = Date.now();
    console.warn(`[AutoPing] ${provider}:${connection.id}: ping failed (${resetAt ? `reset ${resetAt}` : "inactive session"})`);
    return;
  }

  if (inactiveSession) (state.pingCache ??= {})[key] = Date.now();
  delete state.failureCache[key];
  await deps.updateProviderConnection(connection.id, {
    ...(resetAt ? { lastPingedResetAt: resetAt, lastPingedResetKey: resetKey } : {}),
    lastPingAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });
  if (inactiveSession) delete state.pingCache[key];
  console.log(`[AutoPing] ${provider}:${connection.id}: ping sent (${resetAt ? `reset ${resetAt}` : "inactive session"})`);
}

function createDefaultDeps() {
  return {
    getSettings,
    getProviderConnections,
    updateProviderConnection,
    resolveConnectionProxyConfig,
    refreshAndUpdateCredentials,
    proxyAwareFetch,
    getExecutor,
  };
}

export async function runQuotaAutoPingTick(deps = createDefaultDeps(), state = g) {
  if (state.running) return;
  state.running = true;
  try {
    const settings = await deps.getSettings();

    for (const [provider, providerConfig] of Object.entries(C.providers)) {
      const handler = providerHandlers[provider];
      if (!handler) continue;

      const enabledMap = settings?.[providerConfig.settingsKey]?.connections || {};
      if (Object.keys(enabledMap).length === 0) continue;

      const conns = await deps.getProviderConnections({ provider, isActive: true });
      const targets = conns.filter((conn) => conn.authType === "oauth" && enabledMap[conn.id] === true);
      for (const conn of targets) {
        try {
          await pingConnection(conn, provider, providerConfig, handler, deps, state);
        } catch (e) {
          state.failureCache[cacheKey(provider, conn.id)] = Date.now();
          console.warn(`[AutoPing] ${provider}:${conn.id}: ${e.message}`);
        }
      }
    }
  } catch (e) {
    console.warn("[AutoPing] tick error:", e.message);
  } finally {
    state.running = false;
  }
}

export function startQuotaAutoPing() {
  if (g.interval) return;
  console.log("[AutoPing] scheduler started");
  runQuotaAutoPingTick().catch(() => {});
  g.interval = setInterval(() => { runQuotaAutoPingTick().catch(() => {}); }, C.tickIntervalMs);
  if (g.interval.unref) g.interval.unref();
}

export function stopQuotaAutoPing() {
  if (!g.interval) return;
  clearInterval(g.interval);
  g.interval = null;
  console.log("[AutoPing] scheduler stopped");
}

export function configureQuotaAutoPing(settings) {
  const enabled = Object.values(C.providers).some((providerConfig) =>
    Object.values(settings?.[providerConfig.settingsKey]?.connections || {}).some(Boolean)
  );
  if (enabled) startQuotaAutoPing();
  else stopQuotaAutoPing();
}
